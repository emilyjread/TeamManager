import React, {useEffect, useState} from 'react'
import Form from '../components/Form';

const Main= ()=>{  
    return(
        <Form/>
    )
}

export default Main